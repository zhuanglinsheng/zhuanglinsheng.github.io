from typing import Optional

import numpy as np
from scipy.stats import norm, expon, binom, arcsine, cauchy, gamma, logistic, levy, t
from scipy.optimize import OptimizeResult, minimize, minimize_scalar, root, root_scalar


def training_perf_CES(alpha: float, r: float, d: float, d_F: list[float]) -> float:
	'''The function D(d1, d2)
	'''
	mixing = alpha * d ** r + (1 - alpha) * np.power(d_F, r).sum()
	return mixing ** (1 / r)

def training_perf_simpler(r: float, d: float, d_F: list[float]) -> float:
	'''The function D(d1, d2)
	'''
	return r * (d + np.sum(d_F)) + (1 - 2 * r) * d * np.prod(d_F)

def data_collection_cost(d: float) -> float:
	'''The function c(.)
	'''
	return d**2

def marginal_data_collection_cost(d: float) -> float:
	'''The function c'(.)
	'''
	return 2 * d

def A_n(n: int, dist: str = 'norm') -> float:
	'''
	Derivative of the winning probability in symmetric equilibrium:
		A_n = (n-1) * integral of F(x)^{n - 2} * f^2(x) dx
	'''
	if n - 1 <= 0:
		return 0.0
	if 'norm' == dist:
		re = (n - 1) * norm.expect(
			lambda x: norm.cdf(x, loc=0) ** (n - 2) * norm.pdf(x, loc=0), loc=0, scale=1)
	elif 'expon' == dist:
		re = (n - 1) * expon.expect(
			lambda x: expon.cdf(x) ** (n - 3) * expon.pdf(x), loc=0, scale=1)
	elif 'arcsine' == dist:
		re = (n - 1) * arcsine.expect(
			lambda x: arcsine.cdf(x + 0.5) ** (n - 1 - 1) * arcsine.pdf(x + 0.5), loc=0, scale=1)
	elif 'cauchy' == dist:
		re = (n - 1) * cauchy.expect(
			lambda x: cauchy.cdf(x) ** (n - 2) * cauchy.pdf(x), loc=0, scale=1)
	elif 'gamma' == dist:
		a = 1
		re = (n - 1) * gamma.expect(
			lambda x: gamma.cdf(x, a) ** (n - 2) * gamma.pdf(x, a), args=(a,), loc=0, scale=1)
	elif 'levy' == dist:
		re = (n - 1) * levy.expect(
			lambda x: levy.cdf(x) ** (n - 2) * levy.pdf(x), loc=0, scale=1)
	elif 'logistic' == dist:
		re = (n - 1) * logistic.expect(
			lambda x: logistic.cdf(x) ** (n - 2) * logistic.pdf(x), loc=0, scale=1)
	elif 't' == dist:
		df = 10
		re = (n - 1) * t.expect(
			lambda x: t.cdf(x, df) ** (n - 2) * t.pdf(x, df), args=(df,), loc=0, scale=1)
	return float(re) # type: ignore

def E_A(n: int, p: float, Ans: list) -> float:
	'''Calculate E(A_N) w.r.t. N ~ Bin(n-1, p)
	'''
	S = 0
	for k in range(n):
		prob = binom.pmf(k, n - 1, p)
		S += prob * Ans[k]
	return S

class Game():
	n: int
	alpha: float
	r: float

	M1: float
	M2: float
	sigma1: float
	sigma2: float
	An: float

	def __init__(self, n, alpha, r, M1, M2, sigma1, sigma2, dist: str = 'norm'):
		self.n = n
		self.alpha = alpha
		self.r = r
		self.M1 = M1
		self.M2 = M2
		self.sigma1 = sigma1
		self.sigma2 = sigma2
		self.An = A_n(n, dist)
		if r >= 2 and r != float('inf'):
			raise ValueError('Expect 0 < r < 2 or r = Infinity, get {}'.format(r))

	def _solve_eq_r_small(self, theta_1: float, theta_2: float) -> tuple[float, float]:
		"""
		"""
		def res(ds: list[float]):
			d1, d2 = ds[0], ds[1]
			tilde_M1 = self.M1 / self.sigma1
			tilde_M2 = self.M2 / self.sigma2
			train_pf_1 = training_perf_CES(self.alpha, self.r, d1, [d2])
			train_pf_2 = training_perf_CES(1 - self.alpha, self.r, d2, [d1])
			pwr = 1 - self.r
			res1 = self.alpha * tilde_M1 * (train_pf_1 / d1) ** pwr \
				+ (1 - self.alpha) * tilde_M2 * (train_pf_2 / d1) ** pwr * theta_1 ** self.r
			res2 = (1 - self.alpha) * tilde_M1 * (train_pf_1 / d2) ** pwr * theta_2 ** self.r\
				 + self.alpha * tilde_M2 * (train_pf_2 / d2) ** pwr
			return \
				res1 - marginal_data_collection_cost(d1) / self.An, \
				res2 - marginal_data_collection_cost(d2) / self.An

		sol = root(res, x0=[0.9, 0.9])
		if sol.success is not True:
			print(sol)
			raise RuntimeError('Root finding failure in function "Game._solve_eq_r_small"')
		return sol.x[0], sol.x[1]

	def _solve_eq_r_inf_case_1(self, theta_1: float, theta_2: float) -> tuple[bool, float, float]:
		"""
		"""
		success = True
		sol = root_scalar(
			lambda d2: theta_1 * self.M1 / self.sigma1 + self.M2 / self.sigma2 - marginal_data_collection_cost(d2) / self.An, x0=1.)
		if sol.converged is not True:
			raise RuntimeError('Root finding failure in function "Game._solve_eq_r_inf_case_1" (1)')
		d1 = 0
		d2 = sol.root
		## check deviation value
		def value_deviation(di1):
			intgrl = norm.expect(
				lambda x: norm.cdf(x + di1 / self.sigma1) ** (self.n - 1), loc=0, scale=1)
			return data_collection_cost(di1) - (intgrl - 1 / self.n) * self.M1

		sol = minimize_scalar(value_deviation, bounds=[d2 * theta_2, d2 / theta_1])
		assert isinstance(sol, OptimizeResult)

		if sol.success is not True:
			raise RuntimeError('Root finding failure in function "Game._solve_eq_r_inf_case_1" (2)')
		if -sol.fun > 0:
			success = False
		return success, d1, d2

	def _solve_eq_r_inf_case_2(self, theta_1: float, theta_2: float) -> tuple[bool, float, float]:
		"""
		"""
		success = True
		sol = root_scalar(
			lambda d1: theta_2 * self.M2 / self.sigma2 + self.M1 / self.sigma1 - marginal_data_collection_cost(d1) / self.An, x0=1.)
		if sol.converged is not True:
			raise RuntimeError('Root finding failure in function "Game._solve_eq_r_inf_case_2" (1)')
		d2 = 0
		d1 = sol.root

		## check deviation value
		def value_deviation(di2):
			intgrl = norm.expect(
				lambda x: norm.cdf(x + di2 / self.sigma2) ** (self.n - 1), loc=0, scale=1)
			return data_collection_cost(di2) - (intgrl - 1 / self.n) * self.M2

		sol = minimize_scalar(value_deviation, bounds=[d1 * theta_1, d1 / theta_2])
		assert isinstance(sol, OptimizeResult)

		if sol.success is not True:
			raise RuntimeError('Root finding failure in function "Game._solve_eq_r_inf_case_2" (2)')
		if -sol.fun > 0:
			success = False
		return success, d1, d2

	def _solve_eq_r_inf_case_3(self) -> tuple[float, float]:
		"""
		"""
		sol1 = root_scalar(lambda d1: self.M1 / self.sigma1 - marginal_data_collection_cost(d1) / self.An, x0=1.)
		sol2 = root_scalar(lambda d2: self.M2 / self.sigma2 - marginal_data_collection_cost(d2) / self.An, x0=1.)
		if sol1.converged is not True:
			raise RuntimeError('Root finding failure in function "Game._solve_eq_r_inf_case_3" (1)')
		if sol2.converged is not True:
			raise RuntimeError('Root finding failure in function "Game._solve_eq_r_inf_case_3" (2)')
		return sol1.root, sol2.root

	def _solve_eq_r_inf(self, theta_1: float, theta_2: float) -> tuple[float, float]:
		# case 1:
		success, d1, d2 = self._solve_eq_r_inf_case_1(theta_1, theta_2)
		if success is True:
			return d1, d2
		# case 2
		success, d1, d2 = self._solve_eq_r_inf_case_2(theta_1, theta_2)
		if success is True:
			return d1, d2
		return self._solve_eq_r_inf_case_3()

	def equillirbium(self, theta_1: float, theta_2: float) -> Optional[tuple[float, float]]:
		if self.r < 2:
			return self._solve_eq_r_small(theta_1, theta_2)
		elif self.r == float('inf'):
			return self._solve_eq_r_inf(theta_1, theta_2)

class Game2():
	n: int
	r: float

	M1: float
	M2: float
	sigma1: float
	sigma2: float
	An: float

	def __init__(self, n, r, M1, M2, sigma1, sigma2, dist: str = 'norm'):
		self.n = n
		self.r = r
		self.M1 = M1
		self.M2 = M2
		self.sigma1 = sigma1
		self.sigma2 = sigma2
		self.An = A_n(n, dist)

	def equilibrium(self, theta_1: float, theta_2: float) -> tuple[float, float]:
		tM1 = self.M1 / self.sigma1
		tM2 = self.M2 / self.sigma2
		common_factor = self.An * (1-2 * self.r) * (tM1 * theta_2 + tM2 * theta_1)
		tmp1 = tM1 + tM2 * theta_1
		tmp2 = tM2 + tM1 * theta_2
		d1: float = self.An * self.r * (tmp1 + common_factor * tmp2) / (1 - common_factor**2)
		d2: float = self.An * self.r * (tmp2 + common_factor * tmp1) / (1 - common_factor**2)
		return d1, d2



# Policy

def privacy_cost(gamma, d, theta) -> float:
	return gamma * theta * d

def data_bundle(r, d, dF, thetaF) -> float:
	return r * (d + thetaF * dF) + (1 - 2 * r) * d * (thetaF * dF)

def government_obj(r, d, dF, theta, thetaF, gamma) -> float:
	D = data_bundle(r, d, dF, thetaF)
	C = privacy_cost(gamma, d, theta)
	return D - C

def simultaneous_eq(game: Game2, gamma1: float, gamma2: float):
	eps = 5e-4
	def res(thetas):
		theta1, theta2 = thetas
		d1_1aeps, d2_1aeps = game.equilibrium(theta1 + eps, theta2)
		d1_1meps, d2_1meps = game.equilibrium(theta1 - eps, theta2)
		Pi1_aeps = government_obj(game.r, d1_1aeps, d2_1aeps, theta1 + eps, theta2, gamma1)
		Pi1_meps = government_obj(game.r, d1_1meps, d2_1meps, theta1 - eps, theta2, gamma1)
		Pi1_derivative = (Pi1_aeps - Pi1_meps) / (2 * eps)

		d1_2aeps, d2_2aeps = game.equilibrium(theta1, theta2 + eps)
		d1_2meps, d2_2meps = game.equilibrium(theta1, theta2 - eps)
		Pi2_aeps = government_obj(game.r, d2_2aeps, d1_2aeps, theta2 + eps, theta1, gamma2)
		Pi2_meps = government_obj(game.r, d2_2meps, d1_2meps, theta2 - eps, theta1, gamma2)
		Pi2_derivative = (Pi2_aeps - Pi2_meps) / (2 * eps)
		return Pi1_derivative, Pi2_derivative
	solution = root(fun=res, x0=(0.5, 0.5))
	if solution.success:
		theta1_eq, theta2_eq = solution.x
		if theta1_eq < 0:
			theta1_eq = 0
		if theta1_eq > 1:
			theta1_eq = 1
		if theta2_eq < 0:
			theta2_eq = 0
		if theta2_eq > 1:
			theta2_eq = 1
		return theta1_eq, theta2_eq
	else:
		print("Error...")
		print(solution)
		return None


def stackelberg_eq(game: Game2, gamma1: float, gamma2: float):
	eps = 5e-4

	# Solve theta2_star given theta1
	def optimal_response_2(theta1) -> float | None:
		def res(theta2) -> float:
			"""Phi2'(theta1) = 0
			"""
			d1_2aeps, d2_2aeps = game.equilibrium(theta1, theta2 + eps)
			d1_2meps, d2_2meps = game.equilibrium(theta1, theta2 - eps)
			Pi2_aeps = government_obj(game.r, d2_2aeps, d1_2aeps, theta2 + eps, theta1, gamma2)
			Pi2_mpes = government_obj(game.r, d2_2meps, d1_2meps, theta2 - eps, theta1, gamma2)
			return (Pi2_aeps - Pi2_mpes) / (2 * eps)
		solution_theta2_star = root(fun=res, x0=0.5)
		if not solution_theta2_star.success:
			print("Error...")
			print(solution_theta2_star)
			return None
		if not isinstance(solution_theta2_star.x, float):
			return solution_theta2_star.x[0]
		else:
			return solution_theta2_star.x

	# Solve theta1_star given theta2
	def optimal_response_1(theta2) -> float | None:
		def res(theta1) -> float:
			"""Phi1'(theta2) = 0
			"""
			d1_1aeps, d2_1aeps = game.equilibrium(theta1 + eps, theta2)
			d1_1meps, d2_1meps = game.equilibrium(theta1 - eps, theta2)
			Pi1_aeps = government_obj(game.r, d1_1aeps, d2_1aeps, theta1 + eps, theta2, gamma1)
			Pi1_mpes = government_obj(game.r, d1_1meps, d2_1meps, theta1 - eps, theta2, gamma1)
			return (Pi1_aeps - Pi1_mpes) / (2 * eps)
		solution_theta1_star = root(fun=res, x0=0.5)
		if not solution_theta1_star.success:
			print("Error...")
			print(solution_theta1_star)
			return None
		if not isinstance(solution_theta1_star.x, float):
			return solution_theta1_star.x[0]
		else:
			return solution_theta1_star.x

	# Plugging into theta1_star's problem
	def government_1_res(theta1) -> float | None:
		theta2_star_of_theta1aeps = optimal_response_2(theta1 + eps)
		theta2_star_of_theta1meps = optimal_response_2(theta1 - eps)
		if (theta2_star_of_theta1aeps is None) or (theta2_star_of_theta1meps is None):
			print('Error...')
			return None
		d1_1aeps, d2_1aeps = game.equilibrium(theta1 + eps, theta2_star_of_theta1aeps)
		d1_1meps, d2_1meps = game.equilibrium(theta1 - eps, theta2_star_of_theta1meps)
		Pi1_aeps = government_obj(game.r, d1_1aeps, d2_1aeps, theta1 + eps, theta2_star_of_theta1aeps, gamma1)
		Pi1_meps = government_obj(game.r, d1_1meps, d2_1meps, theta1 - eps, theta2_star_of_theta1meps, gamma1)
		return (Pi1_aeps - Pi1_meps) / (2 * eps)

	solution = root(fun=government_1_res, x0=0.5)  # solve theta_1^*
	if solution.success:
		if not isinstance(solution.x, float):
			theta1_star = solution.x[0]
		else:
			theta1_star = solution.x
		if theta1_star > 1:
			theta1_star = 1
			theta2_star = optimal_response_2(theta1_star)
		elif theta1_star < 0:
			theta1_star = 0
			theta2_star = optimal_response_2(theta1_star)
		else:
			theta2_star = optimal_response_2(theta1_star)
		if theta2_star is None:
			return None
		return theta1_star, theta2_star
	else:
		print("Error...")
		print(solution)
		return None
