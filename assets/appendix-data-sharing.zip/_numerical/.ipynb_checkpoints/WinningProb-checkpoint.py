from scipy.stats import norm
from scipy.stats import binom

def d_winning_prob(narr):
    '''A_n = (n-1) \int \Phi(x)^{n-1} \phi(x)^2 dx
    '''
    return [(n-1) * norm.expect(lambda x: norm.cdf(x)**(n-2) * norm.pdf(x)) if n > 1 else 0 for n in narr]

def E_d_winning_prob(n, p):
    '''Suppose N ~ Bin(n-1, p), calculate E(A_N)
    '''
    return binom.expect(lambda N: d_winning_prob(N+1), (n-1, p))

